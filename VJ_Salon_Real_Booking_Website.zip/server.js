const express=require("express"), fs=require("fs"), path=require("path"), crypto=require("crypto");
const app=express(); const PORT=process.env.PORT||3000; const DB=path.join(__dirname,"data","bookings.json");
app.use(express.json()); app.use(express.static(path.join(__dirname,"public")));
function read(){try{return JSON.parse(fs.readFileSync(DB,"utf8"))}catch{return []}}
function write(x){fs.writeFileSync(DB,JSON.stringify(x,null,2))}
app.get("/api/slots",(req,res)=>{const date=req.query.date;if(!date)return res.status(400).json({message:"date required"});res.json({booked:read().filter(x=>x.date===date).map(x=>x.time)})});
app.post("/api/book",(req,res)=>{
 const {name,phone,date,time,service}=req.body||{};
 if(!name||!/^[0-9]{10}$/.test(phone)||!date||!time||!service)return res.status(400).json({message:"All fields are required"});
 const all=read();
 // Atomic single-process lock: check + write occurs without yielding between operations.
 // The unique key prevents duplicate date/time even for simultaneous HTTP requests handled by this Node process.
 if(all.some(x=>x.date===date&&x.time===time))return res.status(409).json({message:"Ye time slot abhi kisi aur ne book kar liya hai. Kripya doosra time choose karein."});
 const id="VJ-"+crypto.randomBytes(4).toString("hex").toUpperCase();
 all.push({id,name,phone,date,time,service,createdAt:new Date().toISOString()});write(all);
 res.json({ok:true,id});
});
app.get("/api/health",(req,res)=>res.json({ok:true}));
app.listen(PORT,()=>console.log("VJ Salon running on "+PORT));