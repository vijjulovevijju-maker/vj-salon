VJ SALON REAL BOOKING WEBSITE
Run locally:
1. Install Node.js 18+.
2. In this folder run: npm install
3. Run: npm start
4. Open: http://localhost:3000

REAL DOUBLE-BOOKING:
The backend checks the date+time slot and rejects a second booking with HTTP 409. For a single running Node process this prevents two requests from claiming the same slot because the check/write section does not yield.

FOR PRODUCTION / MULTIPLE SERVER INSTANCES:
Use a shared database (PostgreSQL/Supabase) and a UNIQUE constraint on (date,time), then handle duplicate-key errors. The JSON file is suitable for a simple single-instance deployment/demo, not high-scale production.

WHATSAPP:
After confirmation, the customer gets a WhatsApp button to message the salon number 7000211850. WhatsApp itself is not automatically sent without the customer's action.
